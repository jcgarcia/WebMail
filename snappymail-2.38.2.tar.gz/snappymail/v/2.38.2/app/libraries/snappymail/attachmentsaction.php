<?php

namespace SnappyMail;

class AttachmentsAction
{
	public
		$account = null, // \RainLoop\Model\Account
		$action = '',
		$items = [],
		$filesProvider = null,
		$result = false;
}
