<?php

namespace SnappyMail\Rtf;

class ControlSymbol implements Entity
{
	public string $symbol;
	public /*int|string*/ $parameter;
}
