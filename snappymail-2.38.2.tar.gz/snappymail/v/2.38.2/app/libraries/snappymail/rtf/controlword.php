<?php

namespace SnappyMail\Rtf;

class ControlWord implements Entity
{
	public string $word;
	public int $parameter;
}
