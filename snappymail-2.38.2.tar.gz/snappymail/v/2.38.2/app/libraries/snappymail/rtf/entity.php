<?php

namespace SnappyMail\Rtf;

/*
 * Entity is the parent class of all RTF entities,
 * like Group, ControlWord and ControlSymbol.
 */
interface Entity
{
}
