<?php

namespace SnappyMail\Rtf\Groups;

class Destination extends \SnappyMail\Rtf\Group
{
}
