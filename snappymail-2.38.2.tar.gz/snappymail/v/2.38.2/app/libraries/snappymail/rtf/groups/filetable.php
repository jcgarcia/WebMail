<?php

namespace SnappyMail\Rtf\Groups;

class FileTable extends \SnappyMail\Rtf\Group
{
}
