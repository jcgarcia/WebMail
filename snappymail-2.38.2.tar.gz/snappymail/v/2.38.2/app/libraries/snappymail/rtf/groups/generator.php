<?php

namespace SnappyMail\Rtf\Groups;

class Generator extends Destination
{
}
