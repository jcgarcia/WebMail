<?php

namespace SnappyMail\Rtf\Groups;

class Info extends \SnappyMail\Rtf\Group
{
}
