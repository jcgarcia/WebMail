<?php

namespace SnappyMail\Rtf\Groups;

class ListOverrideTable extends \SnappyMail\Rtf\Group
{
}
