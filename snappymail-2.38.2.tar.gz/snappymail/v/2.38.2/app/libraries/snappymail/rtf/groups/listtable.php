<?php

namespace SnappyMail\Rtf\Groups;

class ListTable extends Destination
{
}
