<?php

namespace SnappyMail\Rtf\Groups;

class ListText extends \SnappyMail\Rtf\Group
{
}
