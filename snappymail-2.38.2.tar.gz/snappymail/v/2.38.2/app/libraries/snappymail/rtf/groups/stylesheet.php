<?php

namespace SnappyMail\Rtf\Groups;

class StyleSheet extends \SnappyMail\Rtf\Group
{
}
